import docker
import time
client = docker.from_env()
tasks = [
    {
        "name": "task1",
        "image": "alpine",
        "command": "sh -c 'echo Task 1 running; sleep 2'",
        "cpus": 0.5,
        "mem_limit": "50m"},
    {
        "name": "task2",
        "image": "alpine",
        "command": "sh -c 'echo Task 2 running; sleep 3'",
        "cpus": 0.5,
        "mem_limit": "50m"},
    {
        "name": "task3",
        "image": "alpine",
        "command": "sh -c 'echo Task 3 running; sleep 1'",
        "cpus": 0.5,
        "mem_limit": "50m"}]
for task in tasks:
    print(f"Starting {task['name']}...")
    container = client.containers.run(
        image=task["image"],
        command=task["command"],
        name=task["name"],
        detach=True,
        cpu_quota=int(task["cpus"] * 100000), 
        mem_limit=task["mem_limit"]            )
    container.wait()
    logs = container.logs().decode("utf-8")
    print(logs)
    container.remove()
    print(f"{task['name']} finished.\n")
print("All tasks completed!")